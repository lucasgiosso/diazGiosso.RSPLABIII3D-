export default class Anuncio{
    constructor(id, titulo, descripcion, transaccion,  precio){
        this.id = id;
        this.titulo = titulo;
        this.transaccion = transaccion;
        this.descripcion = descripcion;
        this.precio = precio;
    }
}